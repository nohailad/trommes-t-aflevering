
const app = Vue.createApp({
    data() {
        return {
            showInstruments : true,
            crash: ['./images/crash.png'],
            kick: ['./images/kick.png'],
            snare: ['./images/snare.png'],
            tom1: ['./images/tom1.png'],
            tom2: ['./images/tom2.png'],
            tom3: ['./images/tom3.png'],
            tom4: ['./images/tom4.png']
        }
    },

    methods: {
        yourName(){
            let output = document.getElementById("ur_name");
            alert("Dit navn er " + output.value + "!");
        },
        yourEmail(){
            let output = document.getElementById("ur_email");
            alert("Din email er " + output.value + "!");
        },
        yourPassword(){
            let output = document.getElementById("ur_password");
            alert("Dit password er " + output.value + "! Sikker på at vi skal se det her??");
        },
        yourNumber(){
            let output = document.getElementById("ur_number");
            alert("Dit nummer er " + output.value + "!");
        },
        yourAddress(){
            let output = document.getElementById("ur_address");
            alert("Din adresse er " + output.value + "!");
        },
        yourZipNumber(){
            let output = document.getElementById("ur_zipnumber");
            alert("Dit postnummer er " + output.value + "!");
        },
        sayHi(){
            let txtName = document.getElementById("txtName");
            let txtOutput = document.getElementById("txtOutput");
            let name = txtName.value;
            txtOutput.innerText = "Velkommen til " + name + "!"
        },
        pCrash(){

            let crashSound = new Audio('./sounds/crash.mp3');
            crashSound.play();
        
        },
        pKick(){

            let kickSound = new Audio('./sounds/kick-bass.mp3');
            kickSound.play();
        
        },
        pSnare(){

            let snareSound = new Audio('./sounds/snare.mp3');
            snareSound.play();
        
        },
        pTom1(){

            let tom1Sound = new Audio('./sounds/tom-1.mp3');
            tom1Sound.play();
        
        },
        pTom2(){

            let tom2Sound = new Audio('./sounds/tom-2.mp3');
            tom2Sound.play();
        
        },
        pTom3(){

            let tom3Sound = new Audio('./sounds/tom-3.mp3');
            tom3Sound.play();
        
        },
        pTom4(){

            let tom4Sound = new Audio('./sounds/tom-4.mp3');
            tom4Sound.play();
        
        }
    }
}
)

app.mount('#app')